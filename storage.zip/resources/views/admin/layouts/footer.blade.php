<footer class="main-footer">
    <strong>Copyright &copy; {{ date('Y') }} <a href="#">Cherished Dream</a>.</strong> All rights reserved.
 </footer>
